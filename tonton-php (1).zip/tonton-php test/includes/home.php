<section class="row wrap">
   <div class="xLarge-4 large-4 medium-12 small-12 xSmall-12">
       <div class="padd-around">
           <div class="padd-around column" id="bloc1">
                <p class="title">IT</p>
               <p>
                   Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Donec sollicitudin molestie malesuada.
               </p>
           </div>
       </div>
   </div>
    <div class="xLarge-4 large-4 medium-12 small-12 xSmall-12">
        <div class="padd-around">
            <div class="padd-around column" id="bloc2">
                <p class="title">R&D</p>
                <p>
                    Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Donec sollicitudin molestie malesuada.
                </p>
            </div>
        </div>
    </div>
    <div class="xLarge-4 large-4 medium-12 small-12 xSmall-12">
        <div class="padd-around">
            <div class="padd-around column" id="bloc3">
                <p class="title">IoT</p>
                <p>
                    Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Donec sollicitudin molestie malesuada.
                </p>
            </div>
        </div>
    </div>
</section>

<section class="row wrap">
    <div class="xLarge-12 large-12 medium-12 small-12 xSmall-12">
        <div class="padd-around" id="middleBG">

        </div>
    </div>
</section>

<section class="row wrap">
    <div class="xLarge-6 large-6 medium-12 small-12 xSmall-12">
        <div class="padd-around fullText">
            <div class="padd-around column">
                <p class="title">Titre</p>
                <p>
                    Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Donec rutrum congue leo eget malesuada.

                    Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Donec sollicitudin molestie malesuada. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quis lorem ut libero malesuada feugiat.

                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque in ipsum id orci porta dapibus. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Pellentesque in ipsum id orci porta dapibus.
                </p>
            </div>
        </div>
    </div>
    <div class="xLarge-6 large-6 medium-12 small-12 xSmall-12">
        <div class="padd-around fullText bg-black">
            <div class="padd-around column">
                <p class="title">Titre</p>
                <p>
                    Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Donec rutrum congue leo eget malesuada.

                    Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Donec sollicitudin molestie malesuada. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quis lorem ut libero malesuada feugiat.

                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque in ipsum id orci porta dapibus. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Pellentesque in ipsum id orci porta dapibus.
                </p>
            </div>
        </div>
    </div>
</section>



<section class="row wrap">
    <div class="xLarge-12 large-12 medium-12 small-12 xSmall-12">
        <div class="padd-around" id="bottomBG">

        </div>
    </div>
</section>


