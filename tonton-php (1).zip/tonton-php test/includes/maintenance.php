<section class="xLarge-12 large-12 medium-12 small-12 xSmall-12 row center fullHeight" id="maintenance">
    <div class="padd-around row specials">
        <p>SIte en maintenance...</p>
    </div>
</section>